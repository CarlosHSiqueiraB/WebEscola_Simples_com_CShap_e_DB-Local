﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using webEscola.Models;

namespace webEscola.Data
{
    public class DBContext : DbContext
    {
        public DBContext (DbContextOptions<DBContext> options)
            : base(options)
        {
        }

        public DbSet<webEscola.Models.Instituicao> Instituicao { get; set; } = default!;

        public DbSet<webEscola.Models.Departamento> Departamento { get; set; } = default!;

        public DbSet<webEscola.Models.Curso> Curso { get; set; } = default!;

        public DbSet<webEscola.Models.Disciplina> Disciplina { get; set; } = default!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<CursoDisciplina>()
                .HasKey(cd => new { cd.CursoID, cd.DisciplinaID });
            modelBuilder.Entity<CursoDisciplina>()
                .HasOne(c => c.Curso)
                .WithMany(cd => cd.CursoDisciplinas)
                .HasForeignKey(c => c.CursoID);

            modelBuilder.Entity<CursoDisciplina>()
                .HasOne(d => d.Disciplina)
                .WithMany(cd => cd.CursoDisciplinas)
                .HasForeignKey(d => d.DisciplinaID);
        }

        public DbSet<webEscola.Models.CursoDisciplina> CursoDisciplina { get; set; } = default!;
    }
}
