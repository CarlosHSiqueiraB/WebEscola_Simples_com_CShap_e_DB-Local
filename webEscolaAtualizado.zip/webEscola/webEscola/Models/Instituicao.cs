﻿using System.ComponentModel.DataAnnotations;

namespace webEscola.Models
{
    public class Instituicao
    {
        [Key]
        public long? InstituicaoID { get; set; }
        public string? Nome { get; set; }
        public string? Endereco { get; set; }
    }
}
