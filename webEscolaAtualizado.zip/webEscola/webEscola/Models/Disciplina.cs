﻿namespace webEscola.Models
{
    public class Disciplina
    {
        public long? DisciplinaID { get; set; }
        public string? Nome { get; set; }

        public virtual ICollection<CursoDisciplina>? CursoDisciplinas { get; set; }
    }
}
