﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using webEscola.Data;
using webEscola.Models;

namespace webEscola.Controllers
{
    public class CursoDisciplinasController : Controller
    {
        private readonly DBContext _context;

        public CursoDisciplinasController(DBContext context)
        {
            _context = context;
        }

        // GET: CursoDisciplinas
        public async Task<IActionResult> Index()
        {
            var dBContext = _context.CursoDisciplina.Include(c => c.Curso).Include(c => c.Disciplina);
            return View(await dBContext.ToListAsync());
        }

        // GET: CursoDisciplinas/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null || _context.CursoDisciplina == null)
            {
                return NotFound();
            }

            var cursoDisciplina = await _context.CursoDisciplina
                .Include(c => c.Curso)
                .Include(c => c.Disciplina)
                .FirstOrDefaultAsync(m => m.CursoID == id);
            if (cursoDisciplina == null)
            {
                return NotFound();
            }

            return View(cursoDisciplina);
        }

        // GET: CursoDisciplinas/Create
        public IActionResult Create()
        {
            ViewData["CursoID"] = new SelectList(_context.Curso, "CursoID", "CursoID");
            ViewData["DisciplinaID"] = new SelectList(_context.Disciplina, "DisciplinaID", "DisciplinaID");
            return View();
        }

        // POST: CursoDisciplinas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CursoID,DisciplinaID")] CursoDisciplina cursoDisciplina)
        {
            if (ModelState.IsValid)
            {
                _context.Add(cursoDisciplina);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CursoID"] = new SelectList(_context.Curso, "CursoID", "CursoID", cursoDisciplina.CursoID);
            ViewData["DisciplinaID"] = new SelectList(_context.Disciplina, "DisciplinaID", "DisciplinaID", cursoDisciplina.DisciplinaID);
            return View(cursoDisciplina);
        }

        // GET: CursoDisciplinas/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null || _context.CursoDisciplina == null)
            {
                return NotFound();
            }

            var cursoDisciplina = await _context.CursoDisciplina.FindAsync(id);
            if (cursoDisciplina == null)
            {
                return NotFound();
            }
            ViewData["CursoID"] = new SelectList(_context.Curso, "CursoID", "CursoID", cursoDisciplina.CursoID);
            ViewData["DisciplinaID"] = new SelectList(_context.Disciplina, "DisciplinaID", "DisciplinaID", cursoDisciplina.DisciplinaID);
            return View(cursoDisciplina);
        }

        // POST: CursoDisciplinas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(long? id, [Bind("CursoID,DisciplinaID")] CursoDisciplina cursoDisciplina)
        {
            if (id != cursoDisciplina.CursoID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(cursoDisciplina);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CursoDisciplinaExists(cursoDisciplina.CursoID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CursoID"] = new SelectList(_context.Curso, "CursoID", "CursoID", cursoDisciplina.CursoID);
            ViewData["DisciplinaID"] = new SelectList(_context.Disciplina, "DisciplinaID", "DisciplinaID", cursoDisciplina.DisciplinaID);
            return View(cursoDisciplina);
        }

        // GET: CursoDisciplinas/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null || _context.CursoDisciplina == null)
            {
                return NotFound();
            }

            var cursoDisciplina = await _context.CursoDisciplina
                .Include(c => c.Curso)
                .Include(c => c.Disciplina)
                .FirstOrDefaultAsync(m => m.CursoID == id);
            if (cursoDisciplina == null)
            {
                return NotFound();
            }

            return View(cursoDisciplina);
        }

        // POST: CursoDisciplinas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long? id)
        {
            if (_context.CursoDisciplina == null)
            {
                return Problem("Entity set 'DBContext.CursoDisciplina'  is null.");
            }
            var cursoDisciplina = await _context.CursoDisciplina.FindAsync(id);
            if (cursoDisciplina != null)
            {
                _context.CursoDisciplina.Remove(cursoDisciplina);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CursoDisciplinaExists(long? id)
        {
          return (_context.CursoDisciplina?.Any(e => e.CursoID == id)).GetValueOrDefault();
        }
    }
}
