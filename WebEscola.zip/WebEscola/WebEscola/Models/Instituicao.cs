﻿using System.ComponentModel.DataAnnotations;

namespace WebEscola.Models
{
    public class Instituicao
    {
        [Key]
        public int? CodInstituicao { get; set; }
        [Required]
        [StringLength(100)]
        public string? Nome { get; set; }
        [Required]
        [StringLength(100)]
        public string? Endereco { get; set; }
    }
}
