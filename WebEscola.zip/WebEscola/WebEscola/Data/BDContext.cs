﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebEscola.Models;

namespace WebEscola.Data
{
    public class BDContext : DbContext
    {
        public BDContext (DbContextOptions<BDContext> options)
            : base(options)
        {
        }

        public DbSet<WebEscola.Models.Instituicao> Instituicao { get; set; } = default!;

        public DbSet<WebEscola.Models.Departamento> Departamento { get; set; } = default!;
    }
}
